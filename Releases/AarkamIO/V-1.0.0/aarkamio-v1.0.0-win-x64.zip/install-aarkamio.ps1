<#
.SYNOPSIS
    AarkamIO Sovereign Enterprise Cloud & Control Plane — Automated Production Installer for Windows.

.DESCRIPTION
    Automates the production deployment of AarkamIO on Windows Server 2022 / Windows Server 2025
    and Windows 10/11 Enterprise (x64).
    AarkamIO serves as the central control plane, S3-compatible REST gateway, Web Console,
    identity/IAM RBAC, and Genesis Ceremony activation portal.
    Integrates seamlessly with:
    - Rokka Sovereign Storage Engine (Coordinator :57774 / Gateway :57772)
    - Abodi Sovereign Hardware Node Agent (:57776)
    - Aarkam Manager (AM CLI)

.PARAMETER InstallDir
    Target directory for AarkamIO binaries. Defaults to 'C:\Program Files\Aarkam\AarkamIO'.

.PARAMETER DataDir
    Directory for data, storage metadata and local configuration. Defaults to 'C:\ProgramData\Aarkam\AarkamIO'.

.PARAMETER SourcePath
    Path to pre-published AarkamIO binaries or release zip archive.

.PARAMETER CoordinatorUrl
    Rokka Coordinator cluster endpoint. Defaults to 'https://localhost:57774'.

.PARAMETER GatewayUrl
    Rokka S3 Gateway endpoint. Defaults to 'https://localhost:57772'.

.PARAMETER AbodiUrl
    Abodi Storage Node Agent endpoint. Defaults to 'https://localhost:57776'.

.PARAMETER AmCliPath
    Path to Aarkam Manager CLI executable. Defaults to 'C:\Program Files\Aarkam\AM\am.exe'.

.PARAMETER HttpPort
    Kestrel HTTP Port. Defaults to 7771.

.PARAMETER HttpsPort
    Kestrel HTTPS Port. Defaults to 57771.

.PARAMETER StartServices
    Immediately starts the AarkamIO Windows Service upon successful installation.

.PARAMETER SkipFirewall
    Skips Windows Defender Firewall rule configuration.

.PARAMETER UserOnly
    Installs for current user without registering Windows Service or requiring Administrator elevation.

.EXAMPLE
    .\install-aarkamio.ps1 -StartServices
#>

[CmdletBinding()]
param(
    [string]$InstallDir = "C:\Program Files\Aarkam\AarkamIO",
    [string]$DataDir = "C:\ProgramData\Aarkam\AarkamIO",
    [string]$SourcePath = "",
    [string]$CoordinatorUrl = "https://localhost:57774",
    [string]$GatewayUrl = "https://localhost:57772",
    [string]$AbodiUrl = "https://localhost:57776",
    [string]$AmCliPath = "C:\Program Files\Aarkam\AM\am.exe",
    [int]$HttpPort = 7771,
    [int]$HttpsPort = 57771,
    [int]$WebHttpPort = 5000,
    [int]$WebHttpsPort = 5001,
    [int]$S3HttpPort = 8080,
    [int]$S3HttpsPort = 8443,
    [switch]$StartServices,
    [switch]$SkipFirewall,
    [switch]$UserOnly
)

$ErrorActionPreference = "Stop"

function Write-Banner {
    Write-Host "======================================================================" -ForegroundColor Cyan
    Write-Host "  AarkamIO Sovereign Enterprise Cloud & Control Plane Installer" -ForegroundColor Green
    Write-Host "  Version: V-1.0.0-GA | Windows Production Release" -ForegroundColor Green
    Write-Host "======================================================================" -ForegroundColor Cyan
}

function Test-Admin {
    $currentIdentity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($currentIdentity)
    return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

Write-Banner

if (-not $UserOnly -and -not (Test-Admin)) {
    Write-Error "Administrator elevation is required for standard installation. Please run PowerShell as Administrator, or pass -UserOnly."
    exit 1
}

if ($UserOnly) {
    if ($InstallDir -eq "C:\Program Files\Aarkam\AarkamIO") {
        $InstallDir = Join-Path $env:LOCALAPPDATA "Aarkam\AarkamIO"
    }
    if ($DataDir -eq "C:\ProgramData\Aarkam\AarkamIO") {
        $DataDir = Join-Path $env:LOCALAPPDATA "Aarkam\AarkamIO\Data"
    }
}

# 1. Verify .NET 10.0 Prerequisites
Write-Host "[1/6] Verifying Microsoft .NET 10.0 runtime..." -ForegroundColor Yellow
$dotnetCmd = Get-Command "dotnet" -ErrorAction SilentlyContinue
if (-not $dotnetCmd) {
    Write-Warning "dotnet command not found in PATH. Ensure .NET 10 ASP.NET Core Runtime is installed."
} else {
    $ver = & dotnet --version
    Write-Host "  Found .NET Runtime: $ver" -ForegroundColor DarkGray
}

# 2. Check Integration Endpoints
Write-Host "[2/6] Verifying Sovereign Substrate Integrations..." -ForegroundColor Yellow
Write-Host "  -> Rokka Coordinator : $CoordinatorUrl" -ForegroundColor DarkGray
Write-Host "  -> Rokka S3 Gateway  : $GatewayUrl" -ForegroundColor DarkGray
Write-Host "  -> Abodi Node Daemon : $AbodiUrl" -ForegroundColor DarkGray
Write-Host "  -> Aarkam AM CLI     : $AmCliPath" -ForegroundColor DarkGray

# 3. Create Directories and Deploy Binaries
Write-Host "[3/6] Deploying AarkamIO binaries to $InstallDir..." -ForegroundColor Yellow
New-Item -ItemType Directory -Force -Path $InstallDir | Out-Null
New-Item -ItemType Directory -Force -Path $DataDir | Out-Null
New-Item -ItemType Directory -Force -Path (Join-Path $DataDir "Logs") | Out-Null

$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path

if ([string]::IsNullOrWhiteSpace($SourcePath)) {
    $SourcePath = $scriptDir
}

if (Test-Path (Join-Path $SourcePath "aarkamio-v1.0.0-win-x64.zip")) {
    Expand-Archive -Path (Join-Path $SourcePath "aarkamio-v1.0.0-win-x64.zip") -DestinationPath $InstallDir -Force
} elseif (Test-Path (Join-Path $SourcePath "Aarkam.dll")) {
    Copy-Item -Path "$SourcePath\*" -Destination $InstallDir -Recurse -Force
} else {
    Write-Error "Could not locate Aarkam.dll or release zip in $SourcePath"
    exit 1
}

# 4. Configure appsettings.json
Write-Host "[4/6] Updating appsettings.json configuration..." -ForegroundColor Yellow
$appSettingsPath = Join-Path $InstallDir "appsettings.json"
if (Test-Path $appSettingsPath) {
    try {
        $rawJson = Get-Content $appSettingsPath -Raw | ConvertFrom-Json
        if (-not $rawJson.Rokka) { $rawJson | Add-Member -MemberType NoteProperty -Name "Rokka" -Value (New-Object PSObject) }
        $rawJson.Rokka.CoordinatorAddress = $CoordinatorUrl
        $rawJson.Rokka.CoordinatorUrl = $CoordinatorUrl
        $rawJson.Rokka.GatewayUrl = $GatewayUrl

        if (-not $rawJson.Aarkam) { $rawJson | Add-Member -MemberType NoteProperty -Name "Aarkam" -Value (New-Object PSObject) }
        $rawJson.Aarkam.GatewayAddress = $GatewayUrl

        if (-not $rawJson.Abodi) { $rawJson | Add-Member -MemberType NoteProperty -Name "Abodi" -Value (New-Object PSObject) }
        $rawJson.Abodi.ServerUrl = $AbodiUrl

        if (-not $rawJson.AmCli) { $rawJson | Add-Member -MemberType NoteProperty -Name "AmCli" -Value (New-Object PSObject) }
        $rawJson.AmCli.BinaryPath = $AmCliPath

        if (-not $rawJson.Kestrel) { $rawJson | Add-Member -MemberType NoteProperty -Name "Kestrel" -Value (New-Object PSObject) }
        if (-not $rawJson.Kestrel.Endpoints) { $rawJson.Kestrel | Add-Member -MemberType NoteProperty -Name "Endpoints" -Value (New-Object PSObject) }
        if (-not $rawJson.Kestrel.Endpoints.Http) { $rawJson.Kestrel.Endpoints | Add-Member -MemberType NoteProperty -Name "Http" -Value (New-Object PSObject) }
        if (-not $rawJson.Kestrel.Endpoints.Https) { $rawJson.Kestrel.Endpoints | Add-Member -MemberType NoteProperty -Name "Https" -Value (New-Object PSObject) }

        $rawJson.Kestrel.Endpoints.Http.Url = "http://0.0.0.0:$HttpPort"
        $rawJson.Kestrel.Endpoints.Https.Url = "https://0.0.0.0:$HttpsPort"

        $rawJson | ConvertTo-Json -Depth 20 | Set-Content $appSettingsPath -Encoding UTF8
        Write-Host "  Successfully synchronized cluster endpoints in appsettings.json." -ForegroundColor DarkGray
    } catch {
        Write-Warning "Could not update appsettings.json dynamically: $_"
    }
}

# 5. Configure Windows Defender Firewall
if (-not $SkipFirewall -and -not $UserOnly) {
    Write-Host "[5/6] Configuring Windows Defender Firewall rules..." -ForegroundColor Yellow
    $ports = @(
        @{ Port = $HttpsPort; Name = "AarkamIO-ControlPlane-HTTPS" },
        @{ Port = $HttpPort; Name = "AarkamIO-ControlPlane-HTTP" },
        @{ Port = $WebHttpsPort; Name = "AarkamIO-WebConsole-HTTPS" },
        @{ Port = $WebHttpPort; Name = "AarkamIO-WebConsole-HTTP" },
        @{ Port = $S3HttpsPort; Name = "AarkamIO-S3-TLS" },
        @{ Port = $S3HttpPort; Name = "AarkamIO-S3-HTTP" }
    )
    foreach ($rule in $ports) {
        Remove-NetFirewallRule -DisplayName $rule.Name -ErrorAction SilentlyContinue | Out-Null
        New-NetFirewallRule -DisplayName $rule.Name -Direction Inbound -Protocol TCP -LocalPort $rule.Port -Action Allow -Profile Any | Out-Null
    }
    Write-Host "  Firewall rules added for ports $HttpsPort, $HttpPort, $WebHttpsPort, $WebHttpPort, $S3HttpsPort, $S3HttpPort." -ForegroundColor DarkGray
} else {
    Write-Host "[5/6] Skipping firewall configuration." -ForegroundColor DarkGray
}

# 6. Register Windows Service
Write-Host "[6/6] Registering AarkamIO Service..." -ForegroundColor Yellow
$serviceName = "AarkamIO"
$exePath = Join-Path $InstallDir "Aarkam.exe"

if (-not $UserOnly) {
    $existingService = Get-Service -Name $serviceName -ErrorAction SilentlyContinue
    if ($existingService) {
        Write-Host "  Stopping and reconfiguring existing $serviceName service..." -ForegroundColor DarkGray
        Stop-Service -Name $serviceName -Force -ErrorAction SilentlyContinue
        Start-Sleep -Seconds 2
        sc.exe config $serviceName binPath= "`"$exePath`"" start= auto | Out-Null
    } else {
        sc.exe create $serviceName binPath= "`"$exePath`"" start= auto DisplayName= "AarkamIO Sovereign Enterprise Cloud" | Out-Null
        sc.exe failure $serviceName reset= 86400 actions= restart/5000/restart/10000/restart/60000 | Out-Null
    }

    # Add to system PATH if not present
    $machinePath = [Environment]::GetEnvironmentVariable("Path", "Machine")
    if ($machinePath -notlike "*$InstallDir*") {
        [Environment]::SetEnvironmentVariable("Path", "$machinePath;$InstallDir", "Machine")
    }

    if ($StartServices) {
        Write-Host "  Starting $serviceName Windows Service..." -ForegroundColor Yellow
        Start-Service -Name $serviceName
        Start-Sleep -Seconds 2
        Get-Service -Name $serviceName
    }
} else {
    Write-Host "  UserOnly mode: Windows service not registered. Launch via: $exePath" -ForegroundColor DarkGray
}

$localIp = (Get-NetIPAddress -AddressFamily IPv4 -InterfaceAlias "Ethernet*", "Wi-Fi*" -ErrorAction SilentlyContinue | Select-Object -ExpandProperty IPAddress -First 1)
if (-not $localIp) { $localIp = "127.0.0.1" }

Write-Host ""
Write-Host "======================================================================" -ForegroundColor Green
Write-Host "  AarkamIO V-1.0.0 Installation Successfully Completed!" -ForegroundColor Green
Write-Host "======================================================================" -ForegroundColor Green
Write-Host "  Installation Directory : $InstallDir"
Write-Host "  Data Directory         : $DataDir"
Write-Host ""
Write-Host "  Genesis Ceremony Web Console:" -ForegroundColor Cyan
Write-Host "    -> https://${localIp}:${HttpsPort}/genesis" -ForegroundColor White
Write-Host "    -> or https://${localIp}:${WebHttpsPort}/genesis" -ForegroundColor White
Write-Host ""
Write-Host "  To launch manually:"
Write-Host "    & '$exePath'"
Write-Host "======================================================================" -ForegroundColor Green
