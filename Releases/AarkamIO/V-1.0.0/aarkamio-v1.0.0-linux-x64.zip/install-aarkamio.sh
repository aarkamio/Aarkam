#!/usr/bin/env bash
# ==============================================================================
# AarkamIO Sovereign Enterprise Cloud & Control Plane Installer (Linux x64)
# Production Air-Gapped Deployment Automation
# ==============================================================================

set -Eeuo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
INSTALL_DIR="/opt/aarkam/aarkamio"
DATA_DIR="/var/lib/aarkam"
LOG_DIR="/var/log/aarkam"
SOURCE_PATH="$SCRIPT_DIR"

HTTP_PORT=7771
HTTPS_PORT=57771
WEB_HTTP_PORT=5000
WEB_HTTPS_PORT=5001
S3_HTTP_PORT=8080
S3_HTTPS_PORT=8443

ROKKA_COORD_URL="https://localhost:57774"
ROKKA_GW_URL="https://localhost:57772"
ABODI_URL="https://localhost:57776"
AM_CLI_PATH="/usr/local/bin/am"

START_SERVICE=false
SKIP_FIREWALL=false

# ------------------------------------------------------------------------------
# CLI Argument Parsing
# ------------------------------------------------------------------------------
while [[ $# -gt 0 ]]; do
    case "$1" in
        --install-dir)
            INSTALL_DIR="$2"
            shift 2
            ;;
        --data-dir)
            DATA_DIR="$2"
            shift 2
            ;;
        --log-dir)
            LOG_DIR="$2"
            shift 2
            ;;
        --source-path)
            SOURCE_PATH="$2"
            shift 2
            ;;
        --coordinator-url)
            ROKKA_COORD_URL="$2"
            shift 2
            ;;
        --rokka-gateway-url)
            ROKKA_GW_URL="$2"
            shift 2
            ;;
        --abodi-url)
            ABODI_URL="$2"
            shift 2
            ;;
        --am-cli-path)
            AM_CLI_PATH="$2"
            shift 2
            ;;
        --http-port)
            HTTP_PORT="$2"
            shift 2
            ;;
        --https-port)
            HTTPS_PORT="$2"
            shift 2
            ;;
        --start-service)
            START_SERVICE=true
            shift
            ;;
        --skip-firewall)
            SKIP_FIREWALL=true
            shift
            ;;
        -h|--help)
            echo "Usage: sudo ./install-aarkamio.sh [options]"
            echo ""
            echo "Options:"
            echo "  --install-dir <path>       Target binary directory (default: /opt/aarkam/aarkamio)"
            echo "  --data-dir <path>          Persistent data directory (default: /var/lib/aarkam)"
            echo "  --log-dir <path>           Log directory (default: /var/log/aarkam)"
            echo "  --coordinator-url <url>    Rokka Coordinator URL (default: https://localhost:57774)"
            echo "  --rokka-gateway-url <url>  Rokka S3 Gateway URL (default: https://localhost:57772)"
            echo "  --abodi-url <url>          Abodi Node Daemon URL (default: https://localhost:57776)"
            echo "  --am-cli-path <path>       Aarkam Manager CLI path (default: /usr/local/bin/am)"
            echo "  --http-port <port>         Kestrel HTTP Port (default: 7771)"
            echo "  --https-port <port>        Kestrel HTTPS Port (default: 57771)"
            echo "  --start-service            Start aarkamio systemd service after installation"
            echo "  --skip-firewall            Skip ufw / firewalld rules configuration"
            echo "  -h, --help                 Display this help message"
            exit 0
            ;;
        *)
            echo "Unknown argument: $1" >&2
            exit 1
            ;;
    esac
done

echo "======================================================================"
echo "  AarkamIO Sovereign Enterprise Cloud & Control Plane Installer"
echo "  Version: V-1.0.0-GA | Air-Gapped Production Release"
echo "======================================================================"

# ------------------------------------------------------------------------------
# 1. Privilege and Environment Verification
# ------------------------------------------------------------------------------
if [[ "$(id -u)" -ne 0 ]]; then
    echo "ERROR: This installer must be executed as root (or via sudo)." >&2
    exit 1
fi

ARCH="$(uname -m)"
if [[ "$ARCH" != "x86_64" ]]; then
    echo "ERROR: AarkamIO requires an x86_64 (amd64) architecture. Detected: $ARCH" >&2
    exit 1
fi

# Check for .NET 10.0 runtime
echo "[1/7] Verifying .NET 10.0 runtime prerequisites..."
if ! command -v dotnet &> /dev/null; then
    echo "WARNING: 'dotnet' command not found."
    echo "AarkamIO requires Microsoft .NET 10.0 ASP.NET Core Runtime."
    echo "Please install 'aspnetcore-runtime-10.0' or '.NET 10 SDK' before starting the service."
else
    DOTNET_VER="$(dotnet --version 2>/dev/null || true)"
    echo "  Found .NET runtime version: $DOTNET_VER"
fi

# Check system memory
TOTAL_RAM_KB="$(grep MemTotal /proc/meminfo | awk '{print $2}')"
TOTAL_RAM_GB=$((TOTAL_RAM_KB / 1024 / 1024))
echo "  Detected Total Memory: ${TOTAL_RAM_GB} GB"
if [[ "$TOTAL_RAM_GB" -lt 8 ]]; then
    echo "WARNING: Minimum recommended memory is 16 GB (8 GB absolute minimum)." >&2
fi

# ------------------------------------------------------------------------------
# 2. Storage Substrate Integrations Verification (Abodi, Rokka, AM CLI)
# ------------------------------------------------------------------------------
echo "[2/7] Verifying Aarkam Sovereign Substrate Integrations..."
echo "  -> Rokka Coordinator Target : $ROKKA_COORD_URL"
echo "  -> Rokka S3 Gateway Target  : $ROKKA_GW_URL"
echo "  -> Abodi Storage Node Agent : $ABODI_URL"
echo "  -> Aarkam Manager (AM CLI)  : $AM_CLI_PATH"

if [[ -x "$AM_CLI_PATH" ]]; then
    echo "  [OK] AM CLI executable found at $AM_CLI_PATH"
else
    echo "  [INFO] AM CLI binary not yet in $AM_CLI_PATH. Ensure 'am' is installed from Releases/Am-Cli/V-1.0.0."
fi

# ------------------------------------------------------------------------------
# 3. System User and Directory Hierarchy
# ------------------------------------------------------------------------------
echo "[3/7] Configuring system service accounts and directories..."
if ! getent group aarkam > /dev/null 2>&1; then
    groupadd --system aarkam
    echo "  Created system group 'aarkam'."
fi

if ! getent passwd aarkam > /dev/null 2>&1; then
    useradd --system --gid aarkam --home-dir "$DATA_DIR" --shell /sbin/nologin \
        --comment "Aarkam Sovereign Storage Service Account" aarkam
    echo "  Created system user 'aarkam'."
fi

mkdir -p "$INSTALL_DIR"
mkdir -p "$DATA_DIR"
mkdir -p "$LOG_DIR"
mkdir -p /etc/aarkam

# ------------------------------------------------------------------------------
# 4. Copying Release Payload
# ------------------------------------------------------------------------------
echo "[4/7] Deploying AarkamIO release payload to $INSTALL_DIR..."
if [[ -f "$SOURCE_PATH/aarkamio-v1.0.0-linux-x64.zip" ]]; then
    unzip -q -o "$SOURCE_PATH/aarkamio-v1.0.0-linux-x64.zip" -d "$INSTALL_DIR"
elif [[ -d "$SOURCE_PATH" && -f "$SOURCE_PATH/Aarkam.dll" ]]; then
    cp -r "$SOURCE_PATH"/* "$INSTALL_DIR/"
elif [[ -f "$SCRIPT_DIR/Aarkam.dll" ]]; then
    cp -r "$SCRIPT_DIR"/* "$INSTALL_DIR/"
else
    echo "ERROR: Unable to locate Aarkam.dll in $SOURCE_PATH or $SCRIPT_DIR" >&2
    exit 1
fi

# Ensure executable launcher permissions
if [[ -f "$INSTALL_DIR/aarkamio" ]]; then
    chmod +x "$INSTALL_DIR/aarkamio"
    ln -sf "$INSTALL_DIR/aarkamio" /usr/local/bin/aarkamio
fi

# ------------------------------------------------------------------------------
# 5. Configuring appsettings.json Topology
# ------------------------------------------------------------------------------
echo "[5/7] Applying cluster topology settings to appsettings.json..."
APP_SETTINGS="$INSTALL_DIR/appsettings.json"
if [[ -f "$APP_SETTINGS" ]] && command -v jq &> /dev/null; then
    TEMP_JSON="$(mktemp)"
    jq \
      --arg coord "$ROKKA_COORD_URL" \
      --arg gw "$ROKKA_GW_URL" \
      --arg abodi "$ABODI_URL" \
      --arg am "$AM_CLI_PATH" \
      --arg http "http://0.0.0.0:${HTTP_PORT}" \
      --arg https "https://0.0.0.0:${HTTPS_PORT}" \
      '
      .Rokka.CoordinatorAddress = $coord |
      .Rokka.CoordinatorUrl = $coord |
      .Rokka.GatewayUrl = $gw |
      .Aarkam.GatewayAddress = $gw |
      .Abodi.ServerUrl = $abodi |
      .AmCli.BinaryPath = $am |
      .Kestrel.Endpoints.Http.Url = $http |
      .Kestrel.Endpoints.Https.Url = $https
      ' "$APP_SETTINGS" > "$TEMP_JSON"
    mv "$TEMP_JSON" "$APP_SETTINGS"
    echo "  Updated Rokka, Abodi, and AM connection endpoints."
else
    echo "  [INFO] jq not installed. Keeping existing appsettings.json defaults."
fi

# Set ownership and security
chown -R aarkam:aarkam "$INSTALL_DIR" "$DATA_DIR" "$LOG_DIR" /etc/aarkam
chmod 750 "$INSTALL_DIR" "$DATA_DIR" "$LOG_DIR"

# ------------------------------------------------------------------------------
# 6. Firewall Configuration
# ------------------------------------------------------------------------------
if [[ "$SKIP_FIREWALL" = false ]]; then
    echo "[6/7] Configuring firewall policies..."
    if command -v ufw &> /dev/null && ufw status | grep -q "Status: active"; then
        ufw allow ${HTTPS_PORT}/tcp comment 'AarkamIO Web Console & Genesis HTTPS' >/dev/null 2>&1 || true
        ufw allow ${HTTP_PORT}/tcp comment 'AarkamIO Web Console HTTP' >/dev/null 2>&1 || true
        ufw allow ${WEB_HTTPS_PORT}/tcp comment 'AarkamIO Console Ingress HTTPS' >/dev/null 2>&1 || true
        ufw allow ${WEB_HTTP_PORT}/tcp comment 'AarkamIO Console Ingress HTTP' >/dev/null 2>&1 || true
        ufw allow ${S3_HTTPS_PORT}/tcp comment 'AarkamIO S3 REST TLS' >/dev/null 2>&1 || true
        ufw allow ${S3_HTTP_PORT}/tcp comment 'AarkamIO S3 REST HTTP' >/dev/null 2>&1 || true
        echo "  Configured UFW rules for ports ${HTTPS_PORT}, ${HTTP_PORT}, ${WEB_HTTPS_PORT}, ${WEB_HTTP_PORT}, ${S3_HTTPS_PORT}, ${S3_HTTP_PORT}."
    elif command -v firewall-cmd &> /dev/null && systemctl is-active --quiet firewalld; then
        firewall-cmd --permanent --add-port=${HTTPS_PORT}/tcp >/dev/null 2>&1 || true
        firewall-cmd --permanent --add-port=${HTTP_PORT}/tcp >/dev/null 2>&1 || true
        firewall-cmd --permanent --add-port=${WEB_HTTPS_PORT}/tcp >/dev/null 2>&1 || true
        firewall-cmd --permanent --add-port=${WEB_HTTP_PORT}/tcp >/dev/null 2>&1 || true
        firewall-cmd --permanent --add-port=${S3_HTTPS_PORT}/tcp >/dev/null 2>&1 || true
        firewall-cmd --permanent --add-port=${S3_HTTP_PORT}/tcp >/dev/null 2>&1 || true
        firewall-cmd --reload >/dev/null 2>&1 || true
        echo "  Configured firewalld rules for ports ${HTTPS_PORT}, ${HTTP_PORT}, ${WEB_HTTPS_PORT}, ${WEB_HTTP_PORT}, ${S3_HTTPS_PORT}, ${S3_HTTP_PORT}."
    else
        echo "  No active firewall daemon detected (ufw / firewalld). Ensure ports ${HTTPS_PORT}, ${HTTP_PORT} are accessible."
    fi
else
    echo "[6/7] Skipping firewall configuration as requested (--skip-firewall)."
fi

# ------------------------------------------------------------------------------
# 7. systemd Service Registration
# ------------------------------------------------------------------------------
echo "[7/7] Installing systemd service 'aarkamio.service'..."
DOTNET_BIN="$(command -v dotnet || echo "/usr/bin/dotnet")"

cat <<EOF > /etc/systemd/system/aarkamio.service
[Unit]
Description=AarkamIO Sovereign Enterprise Cloud & Control Plane
Documentation=https://aarkam.io/
After=network.target network-online.target local-fs.target rokka-coordinator.service rokka-gateway.service
Wants=network-online.target

[Service]
Type=simple
User=aarkam
Group=aarkam
WorkingDirectory=${INSTALL_DIR}
ExecStart=${DOTNET_BIN} ${INSTALL_DIR}/Aarkam.dll
Restart=always
RestartSec=5s

# Security Sandbox Hardening
NoNewPrivileges=true
ProtectSystem=full
ProtectHome=true
PrivateTmp=true

# High-Concurrency File Descriptors
LimitNOFILE=1048576
LimitNPROC=524288
LimitMEMLOCK=infinity

# Environment
Environment=ASPNETCORE_ENVIRONMENT=Production
Environment=DOTNET_CLI_TELEMETRY_OPTOUT=1
Environment=DOTNET_NOLOGO=1

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable aarkamio.service >/dev/null 2>&1 || true

if [[ "$START_SERVICE" = true ]]; then
    echo "  Starting aarkamio service..."
    systemctl start aarkamio.service
    sleep 2
    systemctl status aarkamio.service --no-pager
fi

IP_ADDR="$(hostname -I 2>/dev/null | awk '{print $1}' || echo "127.0.0.1")"

echo ""
echo "======================================================================"
echo "  AarkamIO V-1.0.0 Installation Successfully Completed!"
echo "======================================================================"
echo "  Installed Binaries : $INSTALL_DIR"
echo "  Data Directory     : $DATA_DIR"
echo "  Log Directory      : $LOG_DIR"
echo "  Service Name       : aarkamio.service"
echo ""
echo "  Genesis Ceremony Web Console:"
echo "    -> https://${IP_ADDR}:${HTTPS_PORT}/genesis"
echo "    -> or https://${IP_ADDR}:${WEB_HTTPS_PORT}/genesis"
echo ""
echo "  To start the service manually:"
echo "    sudo systemctl start aarkamio"
echo ""
echo "  To view live service logs:"
echo "    sudo journalctl -u aarkamio -f"
echo "======================================================================"
