<#
.SYNOPSIS
    Rokka Sovereign Storage Engine — Automated Production Installation & Bootstrap Script for Windows.

.DESCRIPTION
    Automates the production deployment of the Rokka Sovereign Storage Engine on
    Windows Server 2022 / Windows Server 2025 and Windows 10/11 Enterprise & Pro (x64).
    Deploys both standalone sovereign daemons:
    - 'rokka-coordinator' (Control Plane, Raft Quorum, HRW Placement) on Ports 7774 / 57774.
    - 'rokka-gateway' (S3 REST API, AES-256-GCM, Ahmodi SIMD Cauchy Erasure Coding) on Ports 7772 / 57772.
    - Creates isolated directories under 'C:\Program Files\Aarkam\Rokka' and 'C:\ProgramData\Rokka'.
    - Configures Windows Defender Firewall rules.
    - Configures Windows Services ('Rokka.Coordinator' and 'Rokka.Gateway') with automatic recovery.
    - Sets Machine or User PATH and broadcasts WM_SETTINGCHANGE for instant recognition.

.PARAMETER InstallDir
    Target directory for Rokka binaries. Defaults to 'C:\Program Files\Aarkam\Rokka' (or '%LOCALAPPDATA%\Aarkam\Rokka' if non-elevated).

.PARAMETER DataDir
    Directory for metadata and persistent state. Defaults to 'C:\ProgramData\Rokka'.

.PARAMETER SourcePath
    Path to pre-published Rokka binaries, release zip archive, or repository root containing src\Rokka.Coordinator.

.PARAMETER MasterKey
    64-character hexadecimal AES-256 master cryptographic key. If omitted, a cryptographically secure random key is generated.

.PARAMETER WalKey
    64-character hexadecimal WAL encryption key for Coordinator metadata. If omitted, a secure key is generated.

.PARAMETER StartServices
    Switch to immediately start the Rokka.Coordinator and Rokka.Gateway Windows Services upon installation.

.PARAMETER SkipFirewall
    Switch to skip Windows Defender Firewall rule configuration.

.PARAMETER UserOnly
    Installs exclusively for the current user without requiring Administrator elevation or Windows Service registration.

.EXAMPLE
    .\install-rokka.ps1 -StartServices

.EXAMPLE
    .\install-rokka.ps1 -SourcePath ".\dist\bundles\rokka-v1.0.0-win-x64.zip" -StartServices
#>

[CmdletBinding()]
param(
    [string]$InstallDir = "",
    [string]$DataDir = "C:\ProgramData\Rokka",
    [string]$SourcePath = "",
    [string]$MasterKey = "",
    [string]$WalKey = "",
    [int]$CoordinatorPort = 7774,
    [int]$CoordinatorHttpsPort = 57774,
    [int]$GatewayPort = 7772,
    [int]$GatewayHttpsPort = 57772,
    [switch]$StartServices,
    [switch]$SkipFirewall,
    [switch]$UserOnly
)

$ErrorActionPreference = "Stop"

function Write-Info  { param([string]$Message) Write-Host "[INFO]  $Message" -ForegroundColor Cyan }
function Write-Ok    { param([string]$Message) Write-Host "[OK]    $Message" -ForegroundColor Green }
function Write-Warn  { param([string]$Message) Write-Host "[WARN]  $Message" -ForegroundColor Yellow }
function Write-Err   { param([string]$Message) Write-Host "[ERROR] $Message" -ForegroundColor Red }

Write-Host "======================================================================" -ForegroundColor Blue
Write-Host " Rokka Sovereign Storage Engine — Production Windows Installer        " -ForegroundColor Cyan
Write-Host " Version: V-1.0.0-GA | Standalone Sovereign Fabric                    " -ForegroundColor Blue
Write-Host "======================================================================" -ForegroundColor Blue

# ------------------------------------------------------------------------------
# 1. Architecture & Elevation Verification
# ------------------------------------------------------------------------------
if ([IntPtr]::Size -ne 8) {
    Write-Err "64-bit architecture (x64) is required. 32-bit execution is unsupported."
    exit 1
}

$isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole(
    [Security.Principal.WindowsBuiltInRole]::Administrator)

if (-not $isAdmin -and -not $UserOnly) {
    Write-Warn "Not running as Administrator. Switching automatically to -UserOnly mode."
    $UserOnly = $true
}

if ($UserOnly) {
    if ([string]::IsNullOrWhiteSpace($InstallDir)) {
        $InstallDir = Join-Path $env:LOCALAPPDATA "Aarkam\Rokka"
    }
    $DataDir = Join-Path $env:LOCALAPPDATA "Aarkam\Rokka\data"
} else {
    if ([string]::IsNullOrWhiteSpace($InstallDir)) {
        $InstallDir = "C:\Program Files\Aarkam\Rokka"
    }
}

Write-Info "Installation Target: $InstallDir"
Write-Info "Data Directory:      $DataDir"

# ------------------------------------------------------------------------------
# 2. Master Key & WAL Key Provisioning
# ------------------------------------------------------------------------------
if ([string]::IsNullOrWhiteSpace($MasterKey)) {
    $bytes = New-Object byte[] 32
    [System.Security.Cryptography.RandomNumberGenerator]::Create().GetBytes($bytes)
    $MasterKey = ($bytes | ForEach-Object { "{0:X2}" -f $_ }) -join ""
    Write-Info "Generated cryptographically secure Master Key (AES-256): $MasterKey"
}

if ([string]::IsNullOrWhiteSpace($WalKey)) {
    $bytes = New-Object byte[] 32
    [System.Security.Cryptography.RandomNumberGenerator]::Create().GetBytes($bytes)
    $WalKey = ($bytes | ForEach-Object { "{0:X2}" -f $_ }) -join ""
    Write-Info "Generated cryptographically secure WAL Encryption Key: $WalKey"
}

# ------------------------------------------------------------------------------
# 3. Locate Source Binaries
# ------------------------------------------------------------------------------
$ScriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$candidatePaths = @(
    $SourcePath,
    $ScriptRoot,
    (Join-Path $ScriptRoot "..\dist\bundles\rokka-v1.0.0-win-x64.zip"),
    (Join-Path $ScriptRoot "..\dist\staging\win-x64"),
    (Join-Path $ScriptRoot "..\dist\win-x64"),
    (Join-Path $ScriptRoot "..\src\Rokka.Coordinator\bin\Release\net10.0\win-x64")
)

$resolvedCoordExe = ""
$resolvedGatewayExe = ""
$tempZipExtract = ""

foreach ($cand in $candidatePaths) {
    if ([string]::IsNullOrWhiteSpace($cand)) { continue }
    if ((Test-Path $cand -PathType Leaf) -and ($cand.EndsWith(".zip", [System.StringComparison]::OrdinalIgnoreCase))) {
        Write-Info "Unpacking release bundle: $cand"
        $tempZipExtract = Join-Path ([System.IO.Path]::GetTempPath()) ("rokka_inst_" + [Guid]::NewGuid().ToString("N"))
        Expand-Archive -Path $cand -DestinationPath $tempZipExtract -Force
        $cand = $tempZipExtract
    }

    if (Test-Path $cand) {
        $coordCand = Get-ChildItem -Path $cand -Recurse -Filter "*Coordinator.exe" -ErrorAction SilentlyContinue | Select-Object -First 1
        if (-not $coordCand) {
            $coordCand = Get-ChildItem -Path $cand -Recurse -Filter "rokka-coordinator.exe" -ErrorAction SilentlyContinue | Select-Object -First 1
        }

        $gwCand = Get-ChildItem -Path $cand -Recurse -Filter "*Gateway.exe" -ErrorAction SilentlyContinue | Select-Object -First 1
        if (-not $gwCand) {
            $gwCand = Get-ChildItem -Path $cand -Recurse -Filter "rokka-gateway.exe" -ErrorAction SilentlyContinue | Select-Object -First 1
        }

        if ($coordCand -and $gwCand) {
            $resolvedCoordExe = $coordCand.FullName
            $resolvedGatewayExe = $gwCand.FullName
            Write-Ok "Located Coordinator binary: $resolvedCoordExe"
            Write-Ok "Located Gateway binary:     $resolvedGatewayExe"
            break
        }
    }
}

if (-not (Test-Path $resolvedCoordExe) -or -not (Test-Path $resolvedGatewayExe)) {
    Write-Err "Could not locate pre-built Rokka binaries. Please specify -SourcePath to a valid release ZIP or build directory."
    exit 1
}

# ------------------------------------------------------------------------------
# 4. Provision Directory Structure & Deploy Binaries
# ------------------------------------------------------------------------------
$binDir = Join-Path $InstallDir "bin"
$configDir = Join-Path $InstallDir "config"
$metaDir = Join-Path $DataDir "Coordinator\metadata"
$logsDir = Join-Path $DataDir "Logs"

foreach ($dir in @($binDir, $configDir, $metaDir, $logsDir)) {
    if (-not (Test-Path $dir)) {
        New-Item -ItemType Directory -Path $dir -Force | Out-Null
    }
}

Write-Info "Deploying binaries to $binDir..."
$destCoord = Join-Path $binDir "rokka-coordinator.exe"
$destGateway = Join-Path $binDir "rokka-gateway.exe"

Copy-Item -Path $resolvedCoordExe -Destination $destCoord -Force
Copy-Item -Path $resolvedGatewayExe -Destination $destGateway -Force

# Provide backward-compatibility aliases
Copy-Item -Path $destCoord -Destination (Join-Path $binDir "Rokka.Coordinator.exe") -Force
Copy-Item -Path $destGateway -Destination (Join-Path $binDir "Rokka.Gateway.exe") -Force

Write-Ok "Binaries installed successfully."

# ------------------------------------------------------------------------------
# 5. Generate Configuration Files
# ------------------------------------------------------------------------------
$escapedMetaDir = $metaDir.Replace("\", "\\")

$coordConfig = @"
{
  "Logging": {
    "LogLevel": {
      "Default": "Information",
      "Microsoft.AspNetCore": "Warning"
    }
  },
  "AllowedHosts": "*",
  "Security": {
    "RequireOperatorAuth": true
  },
  "Rokka": {
    "BaseDirectory": "$escapedMetaDir",
    "WalEncryptionKey": "$WalKey",
    "DefaultStoragePolicy": "4+2",
    "Transcoder": {
      "Enabled": true,
      "ScanIntervalSeconds": 60,
      "TargetPolicy": "4+2",
      "MaxBytesPerSecond": 40000000,
      "ReclaimOriginalReplicas": true
    }
  },
  "Health": {
    "HeartbeatTimeoutSeconds": 30,
    "ScanIntervalSeconds": 5,
    "MinAvailableBytesThreshold": 1073741824
  },
  "Kestrel": {
    "Endpoints": {
      "gRPC-Http": {
        "Url": "http://0.0.0.0:$CoordinatorPort",
        "Protocols": "Http2"
      },
      "Https": {
        "Url": "https://0.0.0.0:$CoordinatorHttpsPort",
        "Protocols": "Http1AndHttp2"
      }
    }
  }
}
"@

$gwConfig = @"
{
  "Logging": {
    "LogLevel": {
      "Default": "Information",
      "Microsoft.AspNetCore": "Warning"
    }
  },
  "AllowedHosts": "*",
  "Rokka": {
    "CoordinatorAddress": "http://localhost:$CoordinatorPort",
    "DefaultStoragePolicy": "4+2",
    "S3": {
      "AccessKeyId": "rokka_admin",
      "SecretAccessKey": "$MasterKey"
    }
  },
  "Kestrel": {
    "Endpoints": {
      "Http": {
        "Url": "http://0.0.0.0:$GatewayPort",
        "Protocols": "Http1"
      },
      "Https": {
        "Url": "https://0.0.0.0:$GatewayHttpsPort",
        "Protocols": "Http1AndHttp2"
      }
    }
  }
}
"@

$coordConfigFile = Join-Path $configDir "coordinator.settings.json"
$gwConfigFile = Join-Path $configDir "gateway.settings.json"

Set-Content -Path $coordConfigFile -Value $coordConfig -Encoding utf8
Set-Content -Path $gwConfigFile -Value $gwConfig -Encoding utf8

# Also place appsettings.json in binDir for direct execution
Copy-Item -Path $coordConfigFile -Destination (Join-Path $binDir "appsettings.json") -Force
Copy-Item -Path $gwConfigFile -Destination (Join-Path $binDir "gateway.settings.json") -Force

Write-Ok "Configuration generated."

# ------------------------------------------------------------------------------
# 6. Configure Environment Variables
# ------------------------------------------------------------------------------
if (-not $UserOnly) {
    [Environment]::SetEnvironmentVariable("ROKKA_MASTER_KEY", $MasterKey, [EnvironmentVariableTarget]::Machine)
    [Environment]::SetEnvironmentVariable("ROKKA_WAL_ENCRYPTION_KEY", $WalKey, [EnvironmentVariableTarget]::Machine)
} else {
    [Environment]::SetEnvironmentVariable("ROKKA_MASTER_KEY", $MasterKey, [EnvironmentVariableTarget]::User)
    [Environment]::SetEnvironmentVariable("ROKKA_WAL_ENCRYPTION_KEY", $WalKey, [EnvironmentVariableTarget]::User)
}

$env:ROKKA_MASTER_KEY = $MasterKey
$env:ROKKA_WAL_ENCRYPTION_KEY = $WalKey

# ------------------------------------------------------------------------------
# 7. Configure Firewall Rules (Elevated)
# ------------------------------------------------------------------------------
if (-not $UserOnly -and -not $SkipFirewall) {
    Write-Info "Configuring Windows Defender Firewall rules..."
    $rules = @(
        @{ Name = "Rokka-Coordinator-gRPC"; Port = $CoordinatorPort; Protocol = "TCP" },
        @{ Name = "Rokka-Coordinator-HTTPS"; Port = $CoordinatorHttpsPort; Protocol = "TCP" },
        @{ Name = "Rokka-Gateway-S3-HTTP"; Port = $GatewayPort; Protocol = "TCP" },
        @{ Name = "Rokka-Gateway-S3-HTTPS"; Port = $GatewayHttpsPort; Protocol = "TCP" }
    )

    foreach ($rule in $rules) {
        netsh advfirewall firewall delete rule name="$($rule.Name)" | Out-Null
        netsh advfirewall firewall add rule name="$($rule.Name)" dir=in action=allow protocol=$($rule.Protocol) localport=$($rule.Port) profile=any | Out-Null
        Write-Ok "Firewall rule created: $($rule.Name) (Port $($rule.Port)/$($rule.Protocol))"
    }
}

# ------------------------------------------------------------------------------
# 8. Configure Windows Services (Elevated)
# ------------------------------------------------------------------------------
if (-not $UserOnly) {
    Write-Info "Registering Windows Services..."

    # 1. Rokka.Coordinator Service
    $coordServiceName = "Rokka.Coordinator"
    if (Get-Service -Name $coordServiceName -ErrorAction SilentlyContinue) {
        Stop-Service -Name $coordServiceName -Force -ErrorAction SilentlyContinue
        & sc.exe delete $coordServiceName | Out-Null
        Start-Sleep -Seconds 1
    }

    $coordBinPath = "`"$destCoord`" --config `"$coordConfigFile`""
    & sc.exe create $coordServiceName binPath= $coordBinPath start= auto DisplayName= "Rokka Sovereign Storage Coordinator" | Out-Null
    & sc.exe failure $coordServiceName reset= 86400 actions= restart/5000/restart/10000/restart/20000 | Out-Null
    Write-Ok "Registered Windows Service: $coordServiceName"

    # 2. Rokka.Gateway Service
    $gwServiceName = "Rokka.Gateway"
    if (Get-Service -Name $gwServiceName -ErrorAction SilentlyContinue) {
        Stop-Service -Name $gwServiceName -Force -ErrorAction SilentlyContinue
        & sc.exe delete $gwServiceName | Out-Null
        Start-Sleep -Seconds 1
    }

    $gwBinPath = "`"$destGateway`" --config `"$gwConfigFile`""
    & sc.exe create $gwServiceName binPath= $gwBinPath start= auto DisplayName= "Rokka Sovereign Storage Gateway" | Out-Null
    & sc.exe failure $gwServiceName reset= 86400 actions= restart/5000/restart/10000/restart/20000 | Out-Null
    Write-Ok "Registered Windows Service: $gwServiceName"

    if ($StartServices) {
        Write-Info "Starting Rokka services..."
        Start-Service -Name $coordServiceName -ErrorAction SilentlyContinue
        Start-Service -Name $gwServiceName -ErrorAction SilentlyContinue
        Start-Sleep -Seconds 2

        $cStatus = (Get-Service -Name $coordServiceName).Status
        $gStatus = (Get-Service -Name $gwServiceName).Status
        Write-Ok "Coordinator Service Status: $cStatus"
        Write-Ok "Gateway Service Status:     $gStatus"
    }
}

# ------------------------------------------------------------------------------
# 9. Update PATH Environment Variable
# ------------------------------------------------------------------------------
Write-Info "Configuring PATH environment variable..."
$targetScope = if ($UserOnly) { [EnvironmentVariableTarget]::User } else { [EnvironmentVariableTarget]::Machine }
$currentPath = [Environment]::GetEnvironmentVariable("Path", $targetScope)

$paths = ($currentPath -split ';') | Where-Object { -not [string]::IsNullOrWhiteSpace($_) }
if ($paths -notcontains $binDir) {
    $newPath = ($paths + $binDir) -join ';'
    [Environment]::SetEnvironmentVariable("Path", $newPath, $targetScope)
    Write-Ok "Added $binDir to $($targetScope.ToString()) PATH."
} else {
    Write-Ok "$binDir is already in $($targetScope.ToString()) PATH."
}

# Update current session PATH
if ($env:Path -split ';' -notcontains $binDir) {
    $env:Path = "$binDir;$env:Path"
}

# ------------------------------------------------------------------------------
# 10. Clean Temporary Files & Final Verification
# ------------------------------------------------------------------------------
if ($tempZipExtract -and (Test-Path $tempZipExtract)) {
    Remove-Item -Path $tempZipExtract -Recurse -Force -ErrorAction SilentlyContinue
}

Write-Host "`n======================================================================" -ForegroundColor Green
Write-Host " Rokka Sovereign Storage Engine Installation Complete!                " -ForegroundColor Green
Write-Host "======================================================================" -ForegroundColor Green

& $destCoord --version
& $destGateway --version

Write-Host @"

Access Endpoints:
  - Coordinator gRPC:    http://localhost:$CoordinatorPort (gRPC HTTP/2)
  - Coordinator HTTPS:   https://localhost:$CoordinatorHttpsPort (Control Plane)
  - S3 Data Gateway:     http://localhost:$GatewayPort (S3 REST API)
  - S3 HTTPS Gateway:    https://localhost:$GatewayHttpsPort (Secure S3 API)

Master Key (Save in secure vault):
  ROKKA_MASTER_KEY = $MasterKey
"@ -ForegroundColor Cyan
