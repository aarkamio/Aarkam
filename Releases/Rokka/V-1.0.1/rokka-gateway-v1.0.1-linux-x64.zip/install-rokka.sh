#!/usr/bin/env bash
# ==============================================================================
# Rokka Sovereign Storage Engine — Automated Production Installer (Linux x64)
# ==============================================================================

set -Eeuo pipefail

INSTALL_DIR="/opt/aarkam/rokka"
DATA_DIR="/var/lib/rokka"
SOURCE_PATH=""
MASTER_KEY=""
WAL_KEY=""
CA_PASSWORD=""
START_SERVICES=false
SKIP_FIREWALL=false

COORDINATOR_PORT=7774
COORDINATOR_HTTPS_PORT=57774
GATEWAY_PORT=7772
GATEWAY_HTTPS_PORT=57772

while [[ $# -gt 0 ]]; do
    case "$1" in
        --install-dir)
            INSTALL_DIR="$2"
            shift 2
            ;;
        --data-dir)
            DATA_DIR="$2"
            shift 2
            ;;
        --source-path)
            SOURCE_PATH="$2"
            shift 2
            ;;
        --master-key)
            MASTER_KEY="$2"
            shift 2
            ;;
        --wal-key)
            WAL_KEY="$2"
            shift 2
            ;;
        --ca-password)
            CA_PASSWORD="$2"
            shift 2
            ;;
        --start-services)
            START_SERVICES=true
            shift
            ;;
        --skip-firewall)
            SKIP_FIREWALL=true
            shift
            ;;
        *)
            echo "Unknown argument: $1"
            exit 1
            ;;
    esac
done

echo "======================================================================"
echo " Rokka Sovereign Storage Engine — Linux Production Installer"
echo " Version: V-1.0.0-GA | Standalone Sovereign Fabric"
echo "======================================================================"

# 1. Root & Architecture Checks
if [[ "$(uname -m)" != "x86_64" ]]; then
    echo "[ERROR] Only x86_64 (64-bit) architecture is supported."
    exit 1
fi

if [[ $EUID -ne 0 ]]; then
    echo "[ERROR] This installer must be run as root (or with sudo)."
    exit 1
fi

# 2. Key Provisioning
if [[ -z "${MASTER_KEY}" ]]; then
    MASTER_KEY="$(openssl rand -hex 32)"
    echo "[INFO]  Generated random AES-256 Master Key: ${MASTER_KEY}"
fi

if [[ -z "${WAL_KEY}" ]]; then
    WAL_KEY="$(openssl rand -hex 32)"
    echo "[INFO]  Generated random WAL Encryption Key: ${WAL_KEY}"
fi

if [[ -z "${CA_PASSWORD}" ]]; then
    CA_PASSWORD="$(openssl rand -hex 32)"
    echo "[INFO]  Generated random Cluster CA Passphrase: ${CA_PASSWORD}"
fi

# 3. Locate Source Binaries
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CANDIDATE_PATHS=(
    "${SOURCE_PATH}"
    "${SCRIPT_DIR}"
    "${SCRIPT_DIR}/../dist/bundles/rokka-v1.0.0-linux-x64.zip"
    "${SCRIPT_DIR}/../dist/staging/linux-x64"
    "${SCRIPT_DIR}/../dist/linux-x64"
    "${SCRIPT_DIR}/../src/Rokka.Coordinator/bin/Release/net10.0/linux-x64"
)

RESOLVED_COORD=""
RESOLVED_GW=""
TEMP_ZIP_DIR=""

for cand in "${CANDIDATE_PATHS[@]}"; do
    if [[ -z "${cand}" ]]; then continue; fi
    if [[ -f "${cand}" && "${cand}" == *.zip ]]; then
        TEMP_ZIP_DIR="$(mktemp -d /tmp/rokka_inst_XXXXXX)"
        unzip -q "${cand}" -d "${TEMP_ZIP_DIR}"
        cand="${TEMP_ZIP_DIR}"
    fi

    if [[ -d "${cand}" ]]; then
        c_cand="$(find "${cand}" -type f \( -name "rokka-coordinator" -o -name "Rokka.Coordinator" \) | head -n 1 || true)"
        g_cand="$(find "${cand}" -type f \( -name "rokka-gateway" -o -name "Rokka.Gateway" \) | head -n 1 || true)"
        if [[ -n "${c_cand}" && -n "${g_cand}" ]]; then
            RESOLVED_COORD="${c_cand}"
            RESOLVED_GW="${g_cand}"
            break
        fi
    fi
done

if [[ -z "${RESOLVED_COORD}" || -z "${RESOLVED_GW}" ]]; then
    echo "[ERROR] Could not locate pre-built Rokka binaries. Please specify --source-path."
    exit 1
fi

# 4. Provision Directories
BIN_DIR="${INSTALL_DIR}/bin"
CONFIG_DIR="${INSTALL_DIR}/config"
META_DIR="${DATA_DIR}/metadata"
LOGS_DIR="${DATA_DIR}/logs"

mkdir -p "${BIN_DIR}" "${CONFIG_DIR}" "${META_DIR}" "${LOGS_DIR}"
chmod 755 "${INSTALL_DIR}" "${BIN_DIR}" "${CONFIG_DIR}"
chmod 700 "${DATA_DIR}" "${META_DIR}" "${LOGS_DIR}"

# 5. Install Binaries
cp "${RESOLVED_COORD}" "${BIN_DIR}/rokka-coordinator"
cp "${RESOLVED_GW}" "${BIN_DIR}/rokka-gateway"
chmod +x "${BIN_DIR}/rokka-coordinator" "${BIN_DIR}/rokka-gateway"

# Aliases
ln -sf "${BIN_DIR}/rokka-coordinator" "${BIN_DIR}/Rokka.Coordinator"
ln -sf "${BIN_DIR}/rokka-gateway" "${BIN_DIR}/Rokka.Gateway"

echo "[OK]    Binaries deployed to ${BIN_DIR}"

# 6. Generate Configurations
cat <<EOF > "${CONFIG_DIR}/coordinator.settings.json"
{
  "Logging": {
    "LogLevel": {
      "Default": "Information",
      "Microsoft.AspNetCore": "Warning"
    }
  },
  "AllowedHosts": "*",
  "Security": {
    "RequireOperatorAuth": true
  },
  "Rokka": {
    "BaseDirectory": "${META_DIR}",
    "WalEncryptionKey": "${WAL_KEY}",
    "DefaultStoragePolicy": "4+2",
    "Transcoder": {
      "Enabled": true,
      "ScanIntervalSeconds": 60,
      "TargetPolicy": "4+2",
      "MaxBytesPerSecond": 40000000,
      "ReclaimOriginalReplicas": true
    }
  },
  "Health": {
    "HeartbeatTimeoutSeconds": 30,
    "ScanIntervalSeconds": 5,
    "MinAvailableBytesThreshold": 1073741824
  },
  "Kestrel": {
    "Endpoints": {
      "gRPC-Http": {
        "Url": "http://0.0.0.0:${COORDINATOR_PORT}",
        "Protocols": "Http2"
      },
      "Https": {
        "Url": "https://0.0.0.0:${COORDINATOR_HTTPS_PORT}",
        "Protocols": "Http1AndHttp2"
      }
    }
  }
}
EOF

cat <<EOF > "${CONFIG_DIR}/gateway.settings.json"
{
  "Logging": {
    "LogLevel": {
      "Default": "Information",
      "Microsoft.AspNetCore": "Warning"
    }
  },
  "AllowedHosts": "*",
  "Rokka": {
    "CoordinatorAddress": "http://localhost:${COORDINATOR_PORT}",
    "DefaultStoragePolicy": "4+2",
    "S3": {
      "AccessKeyId": "rokka_admin",
      "SecretAccessKey": "${MASTER_KEY}"
    }
  },
  "Kestrel": {
    "Endpoints": {
      "Http": {
        "Url": "http://0.0.0.0:${GATEWAY_PORT}",
        "Protocols": "Http1"
      },
      "Https": {
        "Url": "https://0.0.0.0:${GATEWAY_HTTPS_PORT}",
        "Protocols": "Http1AndHttp2"
      }
    }
  }
}
EOF

# Copy appsettings.json to bin dir for local run
cp "${CONFIG_DIR}/coordinator.settings.json" "${BIN_DIR}/appsettings.json"
cp "${CONFIG_DIR}/gateway.settings.json" "${BIN_DIR}/gateway.settings.json"

chmod 600 "${CONFIG_DIR}"/*.json

# 7. systemd Service Registration
cat <<EOF > /etc/systemd/system/rokka-coordinator.service
[Unit]
Description=Rokka Sovereign Storage Coordinator (Control Plane)
After=network.target network-online.target
Wants=network-online.target

[Service]
Type=simple
User=root
WorkingDirectory=${BIN_DIR}
ExecStart=${BIN_DIR}/rokka-coordinator
Restart=always
RestartSec=5s
LimitNOFILE=65536
LimitMEMLOCK=infinity
Environment="ROKKA_WAL_ENCRYPTION_KEY=${WAL_KEY}"
Environment="ROKKA_CLUSTER_CA_PASSWORD=${CA_PASSWORD}"
Environment="DOTNET_CLI_TELEMETRY_OPTOUT=1"

[Install]
WantedBy=multi-user.target
EOF

cat <<EOF > /etc/systemd/system/rokka-gateway.service
[Unit]
Description=Rokka Sovereign S3 & Data Storage Gateway
After=network.target rokka-coordinator.service
Wants=rokka-coordinator.service

[Service]
Type=simple
User=root
WorkingDirectory=${BIN_DIR}
ExecStart=${BIN_DIR}/rokka-gateway
Restart=always
RestartSec=5s
LimitNOFILE=65536
LimitMEMLOCK=infinity
Environment="ROKKA_MASTER_KEY=${MASTER_KEY}"
Environment="DOTNET_CLI_TELEMETRY_OPTOUT=1"

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
echo "[OK]    systemd services registered."

# 8. Firewall Configuration
if [[ "${SKIP_FIREWALL}" != "true" ]]; then
    if command -v ufw >/dev/null 2>&1; then
        ufw allow "${COORDINATOR_PORT}/tcp" comment "Rokka Coordinator gRPC" || true
        ufw allow "${COORDINATOR_HTTPS_PORT}/tcp" comment "Rokka Coordinator HTTPS" || true
        ufw allow "${GATEWAY_PORT}/tcp" comment "Rokka Gateway S3 HTTP" || true
        ufw allow "${GATEWAY_HTTPS_PORT}/tcp" comment "Rokka Gateway S3 HTTPS" || true
        echo "[OK]    ufw firewall rules configured."
    elif command -v firewall-cmd >/dev/null 2>&1; then
        firewall-cmd --permanent --add-port="${COORDINATOR_PORT}/tcp" || true
        firewall-cmd --permanent --add-port="${COORDINATOR_HTTPS_PORT}/tcp" || true
        firewall-cmd --permanent --add-port="${GATEWAY_PORT}/tcp" || true
        firewall-cmd --permanent --add-port="${GATEWAY_HTTPS_PORT}/tcp" || true
        firewall-cmd --reload || true
        echo "[OK]    firewalld rules configured."
    fi
fi

# 9. Profile PATH Configuration
echo "export PATH=\"${BIN_DIR}:\$PATH\"" > /etc/profile.d/rokka.sh
chmod 644 /etc/profile.d/rokka.sh

# 10. Start Services if Requested
if [[ "${START_SERVICES}" == "true" ]]; then
    systemctl enable --now rokka-coordinator
    systemctl enable --now rokka-gateway
    echo "[OK]    Rokka services enabled and started."
fi

# Cleanup
if [[ -n "${TEMP_ZIP_DIR}" && -d "${TEMP_ZIP_DIR}" ]]; then
    rm -rf "${TEMP_ZIP_DIR}"
fi

echo "======================================================================"
echo " Rokka Sovereign Storage Engine Installation Complete!"
echo "======================================================================"
"${BIN_DIR}/rokka-coordinator" --version || true
"${BIN_DIR}/rokka-gateway" --version || true

echo "
Access Endpoints:
  - Coordinator gRPC:    http://0.0.0.0:${COORDINATOR_PORT}
  - Coordinator HTTPS:   https://0.0.0.0:${COORDINATOR_HTTPS_PORT}
  - S3 Data Gateway:     http://0.0.0.0:${GATEWAY_PORT}
  - S3 HTTPS Gateway:    https://0.0.0.0:${GATEWAY_HTTPS_PORT}

Master Key (Save in secure vault):
  ROKKA_MASTER_KEY = ${MASTER_KEY}
"
